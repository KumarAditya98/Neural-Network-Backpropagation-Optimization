# Neural-Network-Backpropagation-Optimization
A project on understanding the performance of various different backpropagation optimization techniques in neural networks.
